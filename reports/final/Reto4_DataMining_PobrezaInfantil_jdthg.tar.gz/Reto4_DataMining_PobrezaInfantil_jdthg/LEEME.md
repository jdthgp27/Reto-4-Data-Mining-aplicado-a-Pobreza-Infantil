# Reto 4: Data Mining aplicado a Pobreza Infantil

**Autor:** jdthg
**Modulo:** BI y Big Data - Nivel 5

## Contenido
- 01_codigo/: Scripts Python del pipeline
- 02_informes/: Informes en md, html, pdf
- 03_visualizaciones/: 15 figuras PNG
- 04_modelos/: RandomForest + Kmeans
- 05_datos/: Datasets procesados

## Hallazgo principal
PIB bajo + Pobreza alta multiplica 6.4x el riesgo de mortalidad infantil.
